<?php
/*
Plugin Name: Enhanced Image Viewer
Description: Makes all images in a post clickable, opening them in a new tab with additional functionalities such as Print Image, Download Image as PDF and Download Image.
Version: 1.0
Author: Yasir Majeed
*/


// Register the custom rewrite rule for the image page
function icp_rewrite_rule() {
    add_rewrite_rule('^view-image/([^/]*)/?', 'index.php?image_id=$matches[1]', 'top');
}
add_action('init', 'icp_rewrite_rule');

// Add the custom query var to handle the image URL
function icp_query_vars($vars) {
    $vars[] = 'image_id';
    return $vars;
}
add_filter('query_vars', 'icp_query_vars');

// Load the custom template for viewing the image
function icp_template_include($template) {
    if (get_query_var('image_id')) {
        return plugin_dir_path(__FILE__) . 'templates/view-image.php';
    }
    return $template;
}
add_filter('template_include', 'icp_template_include');

// Make all images clickable in posts
function icp_make_images_clickable($content) {
    if (is_single()) {
        $dom = new DOMDocument();
        @$dom->loadHTML(mb_convert_encoding($content, 'HTML-ENTITIES', 'UTF-8'));
        $images = $dom->getElementsByTagName('img');
        
        foreach ($images as $image) {
            $src = $image->getAttribute('src');
            $encoded_src = urlencode(base64_encode($src));
            $new_link = $dom->createElement('a');
            $new_link->setAttribute('href', site_url('/view-image/' . $encoded_src));
            $new_link->setAttribute('target', '_blank');
            $image->parentNode->replaceChild($new_link, $image);
            $new_link->appendChild($image);
        }

        $content = $dom->saveHTML();
    }

    return $content;
}
add_filter('the_content', 'icp_make_images_clickable');

// Flush rewrite rules on activation and deactivation
function icp_activate() {
    icp_rewrite_rule();
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'icp_activate');

function icp_deactivate() {
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'icp_deactivate');
