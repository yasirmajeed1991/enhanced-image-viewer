<?php
// Get the encoded image URL from the query var
$encodedImageUrl = get_query_var('image_id');
$imageUrl = base64_decode(urldecode($encodedImageUrl));

// Ensure the URL is properly formatted and sanitized
$imageUrl = filter_var($imageUrl, FILTER_SANITIZE_URL);

// Check if the image URL is valid
if (!filter_var($imageUrl, FILTER_VALIDATE_URL)) {
    die('No image specified or image does not exist.');
}

// Check if the image is accessible
$response = @file_get_contents($imageUrl);
if ($response === FALSE) {
    die('No image specified or image does not exist.');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Viewer</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            text-align: center;
            background-color: #f0f0f0;
        }

        img {
            max-width: 100%;
            height: auto;
            margin-top: 20px;
        }

        .icp-buttons {
            margin: 10px 0;
        }

        .icp-buttons button {
            margin-right: 5px;
            padding: 10px 15px;
            font-size: 16px;
            cursor: pointer;
        }

        /* Print-specific styles */
        @media print {
            body * {
                visibility: hidden;
            }
            img {
                visibility: visible;
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                height: auto;
            }
        }
    </style>
</head>
<body>

<div class="icp-buttons">
    <button id="printBtn">Print Image</button>
    <button id="downloadPdfBtn">Download as PDF</button>
    <button id="downloadImgBtn">Download Image</button>
</div>

<img id="imageToDownload" src="<?php echo htmlspecialchars($imageUrl); ?>" alt="Image">

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.5.0-beta4/html2canvas.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script>
    $(document).ready(function() {
        $('#printBtn').click(function() {
            // Open a new window to print only the image
            var printWindow = window.open('', '', 'height=600,width=800');
            printWindow.document.write('<html><head><title>Print Image</title>');
            printWindow.document.write('<style>img { width: 100%; height: auto; }</style></head><body >');
            printWindow.document.write('<img src="' + $('#imageToDownload').attr('src') + '" />');
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.focus();
            printWindow.print();
        });

        $('#downloadPdfBtn').click(function() {
            var img = document.getElementById('imageToDownload');

            html2canvas(img).then(function(canvas) {
                var imgData = canvas.toDataURL('image/png');
                const { jsPDF } = window.jspdf;
                var pdf = new jsPDF();
                pdf.addImage(imgData, 'PNG', 15, 40, 180, 160); // Adjust dimensions as needed
                pdf.save('image.pdf');
            }).catch(function(error) {
                console.error('Error generating PDF:', error);
            });
        });

        $('#downloadImgBtn').click(function() {
            var link = document.createElement('a');
            link.href = $('#imageToDownload').attr('src');
            link.download = 'image';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        });
    });
</script>

</body>
</html>
